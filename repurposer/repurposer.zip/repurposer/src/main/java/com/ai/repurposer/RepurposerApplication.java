package com.ai.repurposer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RepurposerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RepurposerApplication.class, args);
	}

}
