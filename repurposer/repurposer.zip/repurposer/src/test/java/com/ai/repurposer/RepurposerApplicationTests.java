package com.ai.repurposer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RepurposerApplicationTests {

	@Test
	void contextLoads() {
	}

}
